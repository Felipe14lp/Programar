"""
╔═══════════════════════════════════════════════════════════════════════════╗
║           REFERÊNCIA RÁPIDA - JOGO DA VELHA (Consulte Sempre)            ║
║                Dúvidas? Tudo que você precisa está aqui!                 ║
╚═══════════════════════════════════════════════════════════════════════════╝
"""

# ╔═══════════════════════════════════════════════════════════════════════════╗
# ║                          CHEAT SHEET - FÓRMULAS                           ║
# ╚═══════════════════════════════════════════════════════════════════════════╝

print("""
╔════════════════════════════════════════════════════════════════════════════╗
║                    FÓRMULAS QUE VOCÊ VAI USAR                              ║
╚════════════════════════════════════════════════════════════════════════════╝

🔀 CONVERTER POSIÇÃO (1-9) PARA [linha][coluna]:
   linha = (posicao - 1) // 3
   coluna = (posicao - 1) % 3
   
   Exemplo: posicao 5:
   linha = (5-1) // 3 = 4 // 3 = 1
   coluna = (5-1) % 3 = 4 % 3 = 1
   Resultado: [1][1] (o CENTRO!)

📊 CRIAR TABULEIRO VAZIO:
   tabuleiro = [[" " for _ in range(3)] for _ in range(3)]
   OU
   tabuleiro = [[" ", " ", " "],
                 [" ", " ", " "],
                 [" ", " ", " "]]

♻️  TROCAR JOGADOR:
   jogador = "O" if jogador == "X" else "X"

🎯 VERIFICAR 3 IGUAIS EM LINHA:
   if all(celula == jogador for celula in linha):
       # O jogador venceu!
   
🔍 VERIFICAR SE TABULEIRO ESTÁ CHEIO:
   if all(tabuleiro[i][j] != " " for i in range(3) for j in range(3)):
       # É empate!

""")


# ╔═══════════════════════════════════════════════════════════════════════════╗
# ║                    FUNÇÕES ESSENCIAIS DO CÓDIGO                           ║
# ╚═══════════════════════════════════════════════════════════════════════════╝

print("""
╔════════════════════════════════════════════════════════════════════════════╗
║              CÓDIGO DAS 5 PRINCIPAIS FUNÇÕES                               ║
╚════════════════════════════════════════════════════════════════════════════╝

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

1️⃣  EXIBIR TABULEIRO
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

def exibir_tabuleiro(tabuleiro):
    print("\\n")
    for i in range(3):
        print(f" {tabuleiro[i][0]} | {tabuleiro[i][1]} | {tabuleiro[i][2]} ")
        if i < 2:
            print("-----------")
    print("\\n")

O QUE FOMA:
  - Loop 3 vezes (para cada linha do tabuleiro)
  - Print de cada linha com formatação
  - Desenha linhas separadoras


━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

2️⃣  VERIFICAR VITÓRIA  
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

def verificar_vitoria(tabuleiro, jogador):
    # Linhas
    for linha in tabuleiro:
        if all(x == jogador for x in linha):
            return True
    
    # Colunas
    for col in range(3):
        if all(tabuleiro[linha][col] == jogador for linha in range(3)):
            return True
    
    # Diagonal principal
    if all(tabuleiro[i][i] == jogador for i in range(3)):
        return True
    
    # Diagonal secundária
    if all(tabuleiro[i][2-i] == jogador for i in range(3)):
        return True
    
    return False

O QUE FAZ:
  - Checa 3 linhas horizontais
  - Checa 3 colunas verticais
  - Checa diagonal principal (↘)
  - Checa diagonal secundária (↙)
  - Retorna True se encontrar 3 iguais


━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

3️⃣  VERIFICAR EMPATE
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

def verificar_empate(tabuleiro):
    for linha in tabuleiro:
        if " " in linha:
            return False
    return True

O QUE FAZ:
  - Procura por algum espaço vazio
  - Se achar espaço, não é empate (retorna False)
  - Se não achar espaço, é empate (retorna True)


━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

4️⃣  PEGAR MOVIMENTO DO JOGADOR
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

def movimento_jogador(tabuleiro):
    while True:
        try:
            posicao = int(input("Escolha uma posição (1-9): "))
            
            if posicao < 1 or posicao > 9:
                print("Número deve estar entre 1 e 9!")
                continue
            
            linha = (posicao - 1) // 3
            coluna = (posicao - 1) % 3
            
            if tabuleiro[linha][coluna] != " ":
                print("Posição já ocupada!")
                continue
            
            return linha, coluna
        except ValueError:
            print("Digite um número válido!")

O QUE FAZ:
  - Loop até conseguir um movimento válido
  - Valida se é 1-9
  - Valida se position está vazia
  - Converte para coordenadas
  - Retorna [linha][coluna]


━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

5️⃣  LOOP PRINCIPAL DO JOGO
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

tabuleiro = [[" " for _ in range(3)] for _ in range(3)]
jogador = "X"

while True:
    exibir_tabuleiro(tabuleiro)
    
    # Pedir movimento
    linha, coluna = movimento_jogador(tabuleiro)
    tabuleiro[linha][coluna] = jogador
    
    # Verificar vitória
    if verificar_vitoria(tabuleiro, jogador):
        exibir_tabuleiro(tabuleiro)
        print(f"Jogador {jogador} VENCEU! 🎉")
        break
    
    # Verificar empate
    if verificar_empate(tabuleiro):
        exibir_tabuleiro(tabuleiro)
        print("EMPATE! 🤝")
        break
    
    # Trocar jogador
    jogador = "O" if jogador == "X" else "X"

O QUE FAZ:
  - Loop infinito até terminar jogo
  - Mostra o tabuleiro
  - Pede movimento ao jogador
  - Coloca X ou O
  - Verifica vitória
  - Verifica empate
  - Alterna entre X e O

""")


# ╔═══════════════════════════════════════════════════════════════════════════╗
# ║                       ERROS COMUNS E SOLUÇÕES                             ║
# ╚═══════════════════════════════════════════════════════════════════════════╝

print("""
╔════════════════════════════════════════════════════════════════════════════╗
║                   ERROS COMUNS E COMO RESOLVER                             ║
╚════════════════════════════════════════════════════════════════════════════╝

❌ ERRO: IndexError: list index out of range
   CAUSA: Tentou acessar posição que não existe
   SOLUÇÃO: Verifique se linha e coluna estão entre 0 e 2
   
   if linha < 0 or linha > 2 or coluna < 0 or coluna > 2:
       print("Posição inválida!")

❌ ERRO: ValueError: invalid literal for int()
   CAUSA: Usuário digitou uma letra em vez de número
   SOLUÇÃO: Use try/except
   
   try:
       posicao = int(input())
   except ValueError:
       print("Digite um número!")

❌ ERRO: O jogo nunca termina
   CAUSA: Esqueceu de adicionar break
   SOLUÇÃO: Certifique-se de ter break dentro dos if de vitória/empate
   
   if verificar_vitoria(tabuleiro, jogador):
       break  # ← Importante!

❌ ERRO: Posição 5 vai para [0][0] em vez de [1][1]
   CAUSA: Fórmula de conversão errada
   SOLUÇÃO: Use: linha = (pos-1)//3  ,  coluna = (pos-1)%3
   
   ✓ Posição 5: (4)//3=1, (4)%3=1 → [1][1]

❌ ERRO: Vitória nunca é declarada mesmo com 3 na linha
   CAUSA: Verificação de vitória incompleta
   SOLUÇÃO: Verifique LINHAS, COLUNAS e DIAGONAIS
   
   def verificar_vitoria(tabuleiro, jogador):
       # Linhas
       for linha in tabuleiro:
           if all(x == jogador for x in linha):
               return True  # ← Não esqueça!
       # ... resto da função

❌ ERRO: Computador coloca X quando deveria colocar O
   CAUSA: Variável jogador não foi trocada
   SOLUÇÃO: Sempre troque o jogador no final do loop
   
   jogador = "O" if jogador == "X" else "X"

""")


# ╔═══════════════════════════════════════════════════════════════════════════╗
# ║                          DÚVIDAS FREQUENTES                               ║
# ╚═══════════════════════════════════════════════════════════════════════════╝

print("""
╔════════════════════════════════════════════════════════════════════════════╗
║                        PERGUNTAS E RESPOSTAS                               ║
╚════════════════════════════════════════════════════════════════════════════╝

❓ Como funciona "all(x == jogador for x in linha)"?
✓ "all()" retorna True se TODOS os elementos satisfazem a condição
✓ "x == jogador for x in linha" testa cada elemento
✓ Se todos forem iguais a jogador, retorna True

Exemplo:
  linha = ["X", "X", "X"]
  jogador = "X"
  all(x == "X" for x in linha)  →  True ✓
  
  linha = ["X", "O", "X"]
  jogador = "X"
  all(x == "X" for x in linha)  →  False ✗


❓ Por que usar // em vez de /?
✓ "/" retorna float (com decimal): 4/3 = 1.333...
✓ "//" retorna int (inteiro): 4//3 = 1
✓ Usamos // porque precisamos de um número inteiro para o índice


❓ E % (módulo)? Para que serve?
✓ % retorna o RESTO da divisão
✓ 5 % 3 = 2 (5 dividido por 3 = 1 resto 2)
✓ 4 % 3 = 1 (4 dividido por 3 = 1 resto 1)
✓ Usamos para encontrar qual COLUNA


❓ Como faço o computador jogar?
✓ Crie uma função movimento_computador()
✓ Tente vencer se possível
✓ Bloqueie o jogador
✓ Senão, escolha uma posição aleatória
✓ Veja os arquivos já criados para exemplos!


❓ Como adiciono cores ou emojis?
✓ Emojis são fáceis, apenas use na string:
  print("🎮 Bem-vindo ao jogo da velha!")

✓ Cores em Python requerem biblioteca especial:
  from colorama import Fore
  print(Fore.RED + "Texto vermelho")


❓ Como salvo o jogo?
✓ Use json para salvar dados
✓ Serialize o tabuleiro e o jogador atual
✓ Abra e carregue quando necessário
✓ (Assunto avançado, pesquise depois!)

""")


# ╔═══════════════════════════════════════════════════════════════════════════╗
# ║                          CHECKLIST FINAL                                  ║
# ╚═══════════════════════════════════════════════════════════════════════════╝

print("""
╔════════════════════════════════════════════════════════════════════════════╗
║              ANTES DE CONSIDERAR SEU JOGO "PRONTO"                          ║
╚════════════════════════════════════════════════════════════════════════════╝

FUNCIONALIDADES BÁSICAS:
  ☐ Tabuleiro 3x3 funciona
  ☐ Posso entrar com números 1-9
  ☐ Posições inválidas são bloqueadas
  ☐ X e O aparecem corretamente
  ☐ Verifica vitória em linhas
  ☐ Verifica vitória em colunas
  ☐ Verifica vitória em diagonais
  ☐ Verifica empate
  ☐ Jogo termina corretamente

BOM CÓDIGO:
  ☐ Sem erros ou warnings
  ☐ Comentários explicando partes complexas
  ☐ Nomes de variáveis claros
  ☐ Funções bem organizadas
  ☐ Trata erros de entrada do usuário

EXPERIÊNCIA DO USUÁRIO:
  ☐ Mensagens claras e amigáveis
  ☐ Opção de jogar novamente
  ☐ Tabuleiro visualmente agradável
  ☐ Instrções sobre como jogar
  ☐ Emojis ou cores para deixar legal

EXTRAS (BÔNUS):
  ☐ IA do computador
  ☐ Sistema de pontuação
  ☐ Menu inicial
  ☐ Dificuldades (fácil/médio/difícil)
  ☐ Histórico de partidas

""")

print("\n" + "="*80)
print("👉 ARQUIVOS QUE VOCÊ TEM PARA APRENDER:")
print("="*80)
print("""
1. RESUMO VISUAL Jogo da Velha.py
   └─ Explicação rápida visual dos conceitos (leia PRIMEIRO!)

2. AULA Jogo da Velha Explicado.py
   └─ Aula completa passo-a-passo com exemplos (estude DEPOIS!)

3. EXERCÍCIOS Jogo da Velha.py
   └─ 10 exercícios progressivos para você praticar (EXECUTE E TENTE!)

4. Jogo da Velha Básico Python.py
   └─ Versão para 2 jogadores (sirva como referência!)

5. Jogo da Velha 1 Jogador.py
   └─ Versão com IA computador (veja como a IA funciona!)
""")

print("\n" + "="*80)
print("🎓 PRÓXIMOS PASSOS RECOMENDADOS:")
print("="*80)
print("""
1. Leia "RESUMO VISUAL" em 10 minutos
2. Consulte "AULA" para detalhes
3. Tente fazer um jogo do ZERO (sem copiar!)
4. Use esta referência para consultas rápidas
5. Depois programe uma IA
6. Melhore gradualmente seu código
7. Aprenda novas linguagens (Java, JavaScript, etc)
8. Crie projetos mais complexos (4 em linha, xadrez, etc)

✨ BOA SORTE! VOCÊ CONSEGUE! ✨
""")
