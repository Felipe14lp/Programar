"""
JOGO DA VELHA (Tic Tac Toe)
Jogador (X) vs Computador (O)
"""

import random

def exibir_tabuleiro(tabuleiro):
    """Exibe o tabuleiro de forma visual"""
    print("\n")
    for i in range(3):
        print(f" {tabuleiro[i][0]} | {tabuleiro[i][1]} | {tabuleiro[i][2]} ")
        if i < 2:
            print("-----------")
    print("\n")

def exibir_posicoes():
    """Mostra as posições para o jogador escolher"""
    print("Posições disponíveis:")
    print(" 1 | 2 | 3 ")
    print("-----------")
    print(" 4 | 5 | 6 ")
    print("-----------")
    print(" 7 | 8 | 9 ")
    print()

def posicao_para_coordenadas(posicao):
    """Converte posição (1-9) para coordenadas da matriz"""
    posicao -= 1
    linha = posicao // 3
    coluna = posicao % 3
    return linha, coluna

def verificar_vitoria(tabuleiro, jogador):
    """Verifica se o jogador venceu"""
    # Verificar linhas
    for linha in tabuleiro:
        if all(celula == jogador for celula in linha):
            return True
    
    # Verificar colunas
    for coluna in range(3):
        if all(tabuleiro[linha][coluna] == jogador for linha in range(3)):
            return True
    
    # Verificar diagonais
    if all(tabuleiro[i][i] == jogador for i in range(3)):
        return True
    if all(tabuleiro[i][2-i] == jogador for i in range(3)):
        return True
    
    return False

def tabuleiro_cheio(tabuleiro):
    """Verifica se todos os espaços foram preenchidos"""
    for linha in tabuleiro:
        if " " in linha:
            return False
    return True

def obter_movimento_jogador(tabuleiro):
    """Obtém o movimento do jogador"""
    while True:
        try:
            posicao = int(input("Escolha uma posição (1-9): "))
            if posicao < 1 or posicao > 9:
                print("Posição inválida! Escolha entre 1 e 9.")
                continue
            
            linha, coluna = posicao_para_coordenadas(posicao)
            if tabuleiro[linha][coluna] != " ":
                print("Essa posição já está ocupada!")
                continue
            
            return linha, coluna
        except ValueError:
            print("Digite um número válido!")

def obter_movimento_computador(tabuleiro):
    """IA para o computador - tenta vencer ou bloquear"""
    # Tenta vencer
    for i in range(3):
        for j in range(3):
            if tabuleiro[i][j] == " ":
                tabuleiro[i][j] = "O"
                if verificar_vitoria(tabuleiro, "O"):
                    return i, j
                tabuleiro[i][j] = " "
    
    # Tenta bloquear o jogador
    for i in range(3):
        for j in range(3):
            if tabuleiro[i][j] == " ":
                tabuleiro[i][j] = "X"
                if verificar_vitoria(tabuleiro, "X"):
                    tabuleiro[i][j] = " "
                    return i, j
                tabuleiro[i][j] = " "
    
    # Se o centro está livre, toma o centro
    if tabuleiro[1][1] == " ":
        return 1, 1
    
    # Se os cantos estão livres, toma um aleatório
    cantos = [(0, 0), (0, 2), (2, 0), (2, 2)]
    cantos_livres = [c for c in cantos if tabuleiro[c[0]][c[1]] == " "]
    if cantos_livres:
        return random.choice(cantos_livres)
    
    # Caso contrário, toma uma posição aleatória
    posicoes_livres = [(i, j) for i in range(3) for j in range(3) if tabuleiro[i][j] == " "]
    return random.choice(posicoes_livres)

def jogar():
    """Função principal do jogo"""
    print("="*40)
    print("   BEM-VINDO AO JOGO DA VELHA!")
    print("="*40)
    print("\nVocê é X | Computador é O")
    
    # Inicializar tabuleiro
    tabuleiro = [[" " for _ in range(3)] for _ in range(3)]
    
    exibir_posicoes()
    
    # Loop do jogo
    while True:
        # Turno do jogador
        exibir_tabuleiro(tabuleiro)
        print("Sua vez!")
        linha, coluna = obter_movimento_jogador(tabuleiro)
        tabuleiro[linha][coluna] = "X"
        
        # Verificar vitória do jogador
        if verificar_vitoria(tabuleiro, "X"):
            exibir_tabuleiro(tabuleiro)
            print("🎉 PARABÉNS! Você venceu! 🎉")
            break
        
        # Verificar empate
        if tabuleiro_cheio(tabuleiro):
            exibir_tabuleiro(tabuleiro)
            print("🤝 Empate! Ninguém venceu.")
            break
        
        # Turno do computador
        print("Turno do computador...")
        import time
        time.sleep(1)
        linha, coluna = obter_movimento_computador(tabuleiro)
        tabuleiro[linha][coluna] = "O"
        
        # Verificar vitória do computador
        if verificar_vitoria(tabuleiro, "O"):
            exibir_tabuleiro(tabuleiro)
            print("😢 Computador venceu! Tente novamente.")
            break
        
        # Verificar empate
        if tabuleiro_cheio(tabuleiro):
            exibir_tabuleiro(tabuleiro)
            print("🤝 Empate! Ninguém venceu.")
            break
    
    # Perguntar se quer jogar novamente
    while True:
        resposta = input("\nQuer jogar novamente? (S/N): ").strip().upper()
        if resposta == "S":
            jogar()
            return
        elif resposta == "N":
            print("\nObrigado por jogar! Até logo!")
            return
        else:
            print("Digite S ou N!")

if __name__ == "__main__":
    jogar()
