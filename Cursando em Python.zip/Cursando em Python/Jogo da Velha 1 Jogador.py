# JOGO DA VELHA - 1 JOGADOR VS SISTEMA
# Você é X, o computador é O

import random

def exibir_tabuleiro(tabuleiro):
    """Mostra o tabuleiro"""
    print("\n")
    for i in range(3):
        print(f" {tabuleiro[i][0]} | {tabuleiro[i][1]} | {tabuleiro[i][2]} ")
        if i < 2:
            print("-----------")
    print("\n")

def exibir_posicoes():
    """Mostra as posições disponíveis"""
    print("Posições do tabuleiro:")
    print(" 1 | 2 | 3 ")
    print("-----------")
    print(" 4 | 5 | 6 ")
    print("-----------")
    print(" 7 | 8 | 9 ")
    print()

def verificar_vitoria(tabuleiro, jogador):
    """Verifica se alguém venceu"""
    # Linhas
    for linha in tabuleiro:
        if all(x == jogador for x in linha):
            return True
    
    # Colunas
    for col in range(3):
        if all(tabuleiro[linha][col] == jogador for linha in range(3)):
            return True
    
    # Diagonais
    if all(tabuleiro[i][i] == jogador for i in range(3)):
        return True
    if all(tabuleiro[i][2-i] == jogador for i in range(3)):
        return True
    
    return False

def obter_posicoes_livres(tabuleiro):
    """Retorna lista de posições livres (1-9)"""
    livres = []
    for i in range(3):
        for j in range(3):
            if tabuleiro[i][j] == " ":
                posicao = i * 3 + j + 1
                livres.append(posicao)
    return livres

def movimento_jogador(tabuleiro):
    """Obtém o movimento do jogador"""
    while True:
        try:
            pos = int(input("Sua jogada (1-9): "))
            
            if pos not in obter_posicoes_livres(tabuleiro):
                print("Posição inválida ou já ocupada!")
                continue
            
            linha = (pos - 1) // 3
            coluna = (pos - 1) % 3
            return linha, coluna
        except ValueError:
            print("Digite um número válido!")

def movimento_computador(tabuleiro):
    """IA do computador - tenta vencer ou bloquear"""
    # 1. Tenta vencer
    for i in range(3):
        for j in range(3):
            if tabuleiro[i][j] == " ":
                tabuleiro[i][j] = "O"
                if verificar_vitoria(tabuleiro, "O"):
                    tabuleiro[i][j] = " "
                    return i, j
                tabuleiro[i][j] = " "
    
    # 2. Tenta bloquear o jogador
    for i in range(3):
        for j in range(3):
            if tabuleiro[i][j] == " ":
                tabuleiro[i][j] = "X"
                if verificar_vitoria(tabuleiro, "X"):
                    tabuleiro[i][j] = " "
                    return i, j
                tabuleiro[i][j] = " "
    
    # 3. Toma o centro se estiver livre
    if tabuleiro[1][1] == " ":
        return 1, 1
    
    # 4. Toma um canto aleatório
    cantos = [(0, 0), (0, 2), (2, 0), (2, 2)]
    cantos_livres = [c for c in cantos if tabuleiro[c[0]][c[1]] == " "]
    if cantos_livres:
        return random.choice(cantos_livres)
    
    # 5. Toma uma posição aleatória
    posicoes_livres = [(i, j) for i in range(3) for j in range(3) if tabuleiro[i][j] == " "]
    return random.choice(posicoes_livres)

def jogar():
    """Função principal do jogo"""
    print("="*40)
    print("  JOGO DA VELHA - 1 JOGADOR")
    print("="*40)
    print("\nVocê é X | Computador é O\n")
    
    tabuleiro = [[" ", " ", " "],
                 [" ", " ", " "],
                 [" ", " ", " "]]
    
    exibir_posicoes()
    
    while True:
        exibir_tabuleiro(tabuleiro)
        
        # Turno do jogador
        print("Sua vez!")
        linha, coluna = movimento_jogador(tabuleiro)
        tabuleiro[linha][coluna] = "X"
        
        # Verificar vitória do jogador
        if verificar_vitoria(tabuleiro, "X"):
            exibir_tabuleiro(tabuleiro)
            print("🎉 VOCÊ VENCEU! 🎉")
            break
        
        # Verificar empate
        if not obter_posicoes_livres(tabuleiro):
            exibir_tabuleiro(tabuleiro)
            print("🤝 EMPATE!")
            break
        
        # Turno do computador
        print("Turno do computador...")
        import time
        time.sleep(1)
        linha, coluna = movimento_computador(tabuleiro)
        tabuleiro[linha][coluna] = "O"
        
        # Verificar vitória do computador
        if verificar_vitoria(tabuleiro, "O"):
            exibir_tabuleiro(tabuleiro)
            print("😢 Computador venceu!")
            break
        
        # Verificar empate
        if not obter_posicoes_livres(tabuleiro):
            exibir_tabuleiro(tabuleiro)
            print("🤝 EMPATE!")
            break
    
    # Jogar novamente
    while True:
        resposta = input("\nJogar novamente? (S/N): ").strip().upper()
        if resposta == "S":
            jogar()
            return
        elif resposta == "N":
            print("Obrigado por jogar! Até logo!")
            return
        else:
            print("Digite S ou N!")

if __name__ == "__main__":
    jogar()
