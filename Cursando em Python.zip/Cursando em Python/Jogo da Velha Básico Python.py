# JOGO DA VELHA - VERSÃO BÁSICA PYTHON
# Dois jogadores: X e O

def exibir_tabuleiro(tabuleiro):
    """Mostra o tabuleiro"""
    print("\n")
    for i in range(3):
        print(f" {tabuleiro[i][0]} | {tabuleiro[i][1]} | {tabuleiro[i][2]} ")
        if i < 2:
            print("-----------")
    print("\n")

def verificar_vitoria(tabuleiro, jogador):
    """Verifica se alguém venceu"""
    # Linhas
    for linha in tabuleiro:
        if all(x == jogador for x in linha):
            return True
    
    # Colunas
    for col in range(3):
        if all(tabuleiro[linha][col] == jogador for linha in range(3)):
            return True
    
    # Diagonais
    if all(tabuleiro[i][i] == jogador for i in range(3)):
        return True
    if all(tabuleiro[i][2-i] == jogador for i in range(3)):
        return True
    
    return False

def jogar():
    """Função principal"""
    tabuleiro = [[" ", " ", " "],
                 [" ", " ", " "],
                 [" ", " ", " "]]
    
    jogador_atual = "X"
    
    print("BEM-VINDO AO JOGO DA VELHA!")
    print("Posições: 1-9 (esquerda para direita, cima para baixo)")
    
    while True:
        exibir_tabuleiro(tabuleiro)
        
        # Entrada do jogador
        while True:
            try:
                pos = int(input(f"Jogador {jogador_atual}, escolha (1-9): "))
                if pos < 1 or pos > 9:
                    print("Digite um número de 1 a 9!")
                    continue
                
                linha = (pos - 1) // 3
                coluna = (pos - 1) % 3
                
                if tabuleiro[linha][coluna] != " ":
                    print("Posição já ocupada!")
                    continue
                
                tabuleiro[linha][coluna] = jogador_atual
                break
            except ValueError:
                print("Digite um número válido!")
        
        # Verificar vitória
        if verificar_vitoria(tabuleiro, jogador_atual):
            exibir_tabuleiro(tabuleiro)
            print(f"🎉 Jogador {jogador_atual} VENCEU! 🎉")
            break
        
        # Verificar empate
        if all(tabuleiro[i][j] != " " for i in range(3) for j in range(3)):
            exibir_tabuleiro(tabuleiro)
            print("🤝 EMPATE!")
            break
        
        # Trocar jogador
        jogador_atual = "O" if jogador_atual == "X" else "X"

if __name__ == "__main__":
    jogar()
