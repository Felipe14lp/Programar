print ("Hello World")
print(7 + 2)
print("7"-"2")