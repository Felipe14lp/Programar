/**
 * Pergunta de múltipla escolha que herda de Pergunta.
 * 
 * CONCEITOS POO APLICADOS:
 * - HERANÇA: Estende a classe abstrata Pergunta
 * - SUPER(): Chama o construtor da superclasse no construtor
 * - SOBRESCRITA: Implementa verificarResposta() de forma específica
 * - POLIMORFISMO: Pode ser tratada como Pergunta (referência para superclasse)
 * - ENCAPSULAMENTO: Atributos privados com validação
 * 
 * Esta classe implementa uma pergunta com múltiplas opções,
 * que o jogador responde escolhendo uma letra (A, B, C ou D).
 */
public class PerguntaMultiplaEscolha extends Pergunta {
    
    // ENCAPSULAMENTO: Atributos privados
    private String[] opcoes; // Array com as opções [A, B, C, D]
    private char respostaCorretaLetra; // A letra da resposta correta
    
    /**
     * Construtor com super() chamando o construtor da superclasse.
     * 
     * HERANÇA E SUPER(): Demonstra o uso de super() para inicializar
     * atributos da classe pai através do construtor.
     * 
     * @param enunciado o texto da pergunta
     * @param pontosPorAcerto os pontos se acertar
     * @param opcoes array com 4 opções [A, B, C, D]
     * @param respostaCorreta a letra da resposta correta
     */
    public PerguntaMultiplaEscolha(String enunciado, int pontosPorAcerto, 
                                   String[] opcoes, char respostaCorreta) {
        super(enunciado, pontosPorAcerto); // SUPER: Chamando construtor da superclasse
        this.setOpcoes(opcoes);
        this.setRespostaCorretaLetra(respostaCorreta);
    }
    
    // GETTERS E SETTERS COM VALIDAÇÃO
    
    public String[] getOpcoes() {
        return opcoes;
    }
    
    public void setOpcoes(String[] opcoes) {
        if (opcoes == null || opcoes.length != 4) {
            throw new IllegalArgumentException("Deve haver exatamente 4 opções!");
        }
        this.opcoes = opcoes;
    }
    
    public char getRespostaCorretaLetra() {
        return respostaCorretaLetra;
    }
    
    public void setRespostaCorretaLetra(char respostaCorreta) {
        if (!String.valueOf(respostaCorreta).matches("[A-Da-d]")) {
            throw new IllegalArgumentException("Resposta deve ser A, B, C ou D!");
        }
        this.respostaCorretaLetra = Character.toUpperCase(respostaCorreta);
    }
    
    /**
     * SOBRESCRITA: Implementação específica para verificar resposta
     * em pergunta de múltipla escolha.
     * 
     * POLIMORFISMO: Este método sobrescreve o método abstrato da superclasse.
     * 
     * @param resposta a letra da resposta do jogador (A, B, C ou D)
     * @return true se a resposta for correta
     */
    @Override
    public boolean verificarResposta(String resposta) {
        if (resposta == null || resposta.length() != 1) {
            return false;
        }
        
        char respostaLetra = Character.toUpperCase(resposta.charAt(0));
        boolean correta = respostaLetra == respostaCorretaLetra;
        this.setRespostaCorreta(correta);
        this.setRespondida(true);
        return correta;
    }
    
    /**
     * IMPLEMENTAÇÃO DE INTERFACE: Implementa calcularPontuacao() de Pontuavel
     * 
     * Múltipla escolha com bônus: acertou ganha os pontos, errou perde metade.
     * 
     * @return os pontos calculados
     */
    @Override
    public int calcularPontuacao() {
        if (!this.isRespondida()) {
            return 0;
        }
        return this.isRespostaCorreta() ? this.getPontosPorAcerto() : -(this.getPontosPorAcerto() / 2);
    }
    
    /**
     * SOBRESCRITA: Sobrescreve o método exibir() da superclasse
     * para mostrar as opções da pergunta.
     */
    @Override
    public void exibir() {
        super.exibir();
        System.out.println("Opções:");
        for (int i = 0; i < opcoes.length; i++) {
            char letra = (char) ('A' + i);
            System.out.println("  " + letra + ") " + opcoes[i]);
        }
        System.out.print("Sua resposta (A/B/C/D): ");
    }
}
