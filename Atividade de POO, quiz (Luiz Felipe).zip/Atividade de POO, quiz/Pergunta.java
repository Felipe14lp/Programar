/**
 * Classe abstrata que representa uma pergunta genérica do quiz.
 * 
 * CONCEITOS POO APLICADOS:
 * - ABSTRAÇÃO: Classe abstrata com método abstrato verificarResposta
 * - ENCAPSULAMENTO: Atributos privados com validação via getters e setters
 * - VISIBILIDADE: private para atributos, protected para comportamentos herdáveis
 * 
 * Esta classe define o contrato que todas as perguntas devem seguir,
 * permitindo polimorfismo quando diferentes tipos de perguntas são armazenados
 * em uma lista de tipo Pergunta (superclasse).
 */
public abstract class Pergunta implements Pontuavel {
    
    // ENCAPSULAMENTO: Atributos privados
    private String enunciado;
    private int pontosPorAcerto;
    private boolean respondida;
    private boolean respostaCorreta;
    
    /**
     * Construtor protegido para ser usado pelas subclasses.
     * 
     * @param enunciado o texto da pergunta
     * @param pontosPorAcerto a pontuação se acertar
     */
    protected Pergunta(String enunciado, int pontosPorAcerto) {
        this.setEnunciado(enunciado);
        this.setPontosPorAcerto(pontosPorAcerto);
        this.respondida = false;
        this.respostaCorreta = false;
    }
    
    // GETTERS E SETTERS COM VALIDAÇÃO (ENCAPSULAMENTO)
    
    public String getEnunciado() {
        return enunciado;
    }
    
    public void setEnunciado(String enunciado) {
        if (enunciado == null || enunciado.trim().isEmpty()) {
            throw new IllegalArgumentException("Enunciado não pode ser vazio!");
        }
        this.enunciado = enunciado;
    }
    
    public int getPontosPorAcerto() {
        return pontosPorAcerto;
    }
    
    public void setPontosPorAcerto(int pontosPorAcerto) {
        if (pontosPorAcerto < 0) {
            throw new IllegalArgumentException("Pontuação não pode ser negativa!");
        }
        this.pontosPorAcerto = pontosPorAcerto;
    }
    
    public boolean isRespondida() {
        return respondida;
    }
    
    public void setRespondida(boolean respondida) {
        this.respondida = respondida;
    }
    
    public boolean isRespostaCorreta() {
        return respostaCorreta;
    }
    
    public void setRespostaCorreta(boolean respostaCorreta) {
        this.respostaCorreta = respostaCorreta;
    }
    
    /**
     * Método abstrato que deve ser implementado pelas subclasses.
     * Verifica se a resposta fornecida está correta.
     * 
     * ABSTRAÇÃO: Define o contrato que subclasses devem seguir
     * 
     * @param resposta a resposta do jogador
     * @return true se correta, false caso contrário
     */
    public abstract boolean verificarResposta(String resposta);
    
    /**
     * Exibe a pergunta para o jogador.
     * Pode ser sobrescrito pelas subclasses para personalização.
     */
    public void exibir() {
        System.out.println("\n" + enunciado);
    }
}
