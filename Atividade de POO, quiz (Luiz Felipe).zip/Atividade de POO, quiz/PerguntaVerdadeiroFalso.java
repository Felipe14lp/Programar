/**
 * Pergunta de verdadeiro ou falso que herda de Pergunta.
 * 
 * CONCEITOS POO APLICADOS:
 * - HERANÇA: Estende a classe abstrata Pergunta
 * - SUPER(): Chama o construtor da superclasse no construtor
 * - SOBRESCRITA: Implementa verificarResposta() de forma específica
 * - POLIMORFISMO: Pode ser tratada como Pergunta (referência para superclasse)
 * - ENCAPSULAMENTO: Atributos privados com validação
 * 
 * Esta classe implementa uma pergunta dicotômica (verdadeiro/falso),
 * que o jogador responde com "V" ou "F".
 */
public class PerguntaVerdadeiroFalso extends Pergunta {
    
    // ENCAPSULAMENTO: Atributo privado
    private boolean respostaVerdadeira; // true para verdadeiro, false para falso
    
    /**
     * Construtor com super() chamando o construtor da superclasse.
     * 
     * HERANÇA E SUPER(): Demonstra o uso de super() para inicializar
     * atributos da classe pai através do construtor.
     * 
     * @param enunciado o texto da pergunta
     * @param pontosPorAcerto os pontos se acertar
     * @param respostaVerdadeira true se a resposta correta é verdadeira
     */
    public PerguntaVerdadeiroFalso(String enunciado, int pontosPorAcerto, boolean respostaVerdadeira) {
        super(enunciado, pontosPorAcerto); // SUPER: Chamando construtor da superclasse
        this.respostaVerdadeira = respostaVerdadeira;
    }
    
    // GETTERS E SETTERS
    
    public boolean isRespostaVerdadeira() {
        return respostaVerdadeira;
    }
    
    public void setRespostaVerdadeira(boolean respostaVerdadeira) {
        this.respostaVerdadeira = respostaVerdadeira;
    }
    
    /**
     * SOBRESCRITA: Implementação específica para verificar resposta
     * em pergunta de verdadeiro ou falso.
     * 
     * POLIMORFISMO: Este método sobrescreve o método abstrato da superclasse.
     * 
     * @param resposta "V" ou "F" (aceita maiúscula e minúscula)
     * @return true se a resposta for correta
     */
    @Override
    public boolean verificarResposta(String resposta) {
        if (resposta == null || resposta.length() != 1) {
            return false;
        }
        
        char respostaChar = Character.toUpperCase(resposta.charAt(0));
        boolean respostaBooleana = respostaChar == 'V';
        
        boolean correta = respostaBooleana == respostaVerdadeira;
        this.setRespostaCorreta(correta);
        this.setRespondida(true);
        return correta;
    }
    
    /**
     * IMPLEMENTAÇÃO DE INTERFACE: Implementa calcularPontuacao() de Pontuavel
     * 
     * Verdadeiro/Falso com sistema simples: acertou ganha todos os pontos,
     * errou não ganha nada (sem penalidade).
     * 
     * @return os pontos calculados
     */
    @Override
    public int calcularPontuacao() {
        if (!this.isRespondida()) {
            return 0;
        }
        return this.isRespostaCorreta() ? this.getPontosPorAcerto() : 0;
    }
    
    /**
     * SOBRESCRITA: Sobrescreve o método exibir() da superclasse
     * para mostrar as opções verdadeiro/falso.
     */
    @Override
    public void exibir() {
        super.exibir();
        System.out.println("Opções:");
        System.out.println("  V) Verdadeiro");
        System.out.println("  F) Falso");
        System.out.print("Sua resposta (V/F): ");
    }
}
