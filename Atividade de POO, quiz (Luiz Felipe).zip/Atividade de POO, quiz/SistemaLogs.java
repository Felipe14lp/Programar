import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * Classe que registra eventos do quiz.
 * 
 * CONCEITOS POO APLICADOS:
 * - SOBRECARGA DE MÉTODOS: Múltiplas versões de registrarEvento()
 *   com diferentes parâmetros
 * - ENCAPSULAMENTO: Atributos privados com formatação de data/hora
 * - VISIBILIDADE: Métodos públicos para acesso controlado
 * 
 * Esta classe demonstra como usar sobrecarga para fornecer
 * flexibilidade na forma de registrar eventos com diferentes informações.
 */
public class SistemaLogs {
    
    // ENCAPSULAMENTO: Atributo privado para formatação
    private static final DateTimeFormatter formatador = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss");
    
    /**
     * SOBRECARGA: Versão simples com apenas uma mensagem.
     * Registra um evento com uma mensagem simples.
     * 
     * @param mensagem a mensagem de log a registrar
     */
    public void registrarEvento(String mensagem) {
        String dataHora = LocalDateTime.now().format(formatador);
        System.out.println("[LOG " + dataHora + "] " + mensagem);
    }
    
    /**
     * SOBRECARGA: Versão com mensagem e nível de importância.
     * Registra um evento com uma mensagem e um nível (1-3).
     * 
     * @param mensagem a mensagem de log a registrar
     * @param nivel o nível de importância (1: INFO, 2: AVISO, 3: ERRO)
     */
    public void registrarEvento(String mensagem, int nivel) {
        String dataHora = LocalDateTime.now().format(formatador);
        String nivelTexto;
        
        // Validação e formatação do nível
        switch (nivel) {
            case 1:
                nivelTexto = "INFO";
                break;
            case 2:
                nivelTexto = "AVISO";
                break;
            case 3:
                nivelTexto = "ERRO";
                break;
            default:
                nivelTexto = "DESCONHECIDO";
        }
        
        System.out.println("[LOG " + dataHora + " - " + nivelTexto + "] " + mensagem);
    }
    
    /**
     * SOBRECARGA: Versão com mensagem, jogador e resposta.
     * Registra um evento específico de resposta do jogador.
     * 
     * @param mensagem a mensagem de log a registrar
     * @param nomeJogador o nome do jogador
     * @param resposta a resposta fornecida pelo jogador
     */
    public void registrarEvento(String mensagem, String nomeJogador, String resposta) {
        String dataHora = LocalDateTime.now().format(formatador);
        System.out.println("[LOG " + dataHora + "] " + mensagem + 
                         " - Jogador: " + nomeJogador + " | Resposta: " + resposta);
    }
    
    /**
     * SOBRECARGA: Versão com mensagem, jogador, resposta e pontuação.
     * Registra um evento completo de resposta com pontuação obtida.
     * 
     * @param mensagem a mensagem de log a registrar
     * @param nomeJogador o nome do jogador
     * @param resposta a resposta fornecida pelo jogador
     * @param pontuacao os pontos obtidos nesta resposta
     */
    public void registrarEvento(String mensagem, String nomeJogador, String resposta, int pontuacao) {
        String dataHora = LocalDateTime.now().format(formatador);
        String resultadoPontuacao = (pontuacao >= 0) ? "+" + pontuacao : "" + pontuacao;
        System.out.println("[LOG " + dataHora + "] " + mensagem + 
                         " - Jogador: " + nomeJogador + " | Resposta: " + resposta + 
                         " | Pontuação: " + resultadoPontuacao);
    }
}
