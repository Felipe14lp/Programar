import java.util.Scanner;

/**
 * Classe principal que executa o programa.
 * 
 * CONCEITOS POO APLICADOS:
 * - COMPOSIÇÃO: Utiliza Quiz, Jogador e Perguntas
 * - POLIMORFISMO: Cria perguntas de diferentes tipos
 * - ENCAPSULAMENTO: Gerencia entrada/saída do usuário
 * - VISIBILIDADE: Métodos privados e public bem organizados
 * 
 * Esta é a porta de entrada do programa que interage com o usuário,
 * coleta seu nome, cria o quiz e o executa.
 */
public class App {
    
    private static Scanner scanner;
    
    /**
     * Método main - ponto de entrada do programa.
     * 
     * @param args argumentos de linha de comando (não utilizados)
     */
    public static void main(String[] args) {
        scanner = new Scanner(System.in);
        
        try {
            // Solicita o nome do jogador
            System.out.println("========================================");
            System.out.println("       BEM-VINDO AO QUIZ DE POO!       ");
            System.out.println("========================================\n");
            System.out.print("Digite seu nome: ");
            String nomeJogador = scanner.nextLine().trim();
            
            // Valida se o nome foi fornecido
            if (nomeJogador.isEmpty()) {
                System.out.println("Erro: Nome não pode estar vazio!");
                return;
            }
            
            // Cria um novo jogador
            Jogador jogador = new Jogador(nomeJogador);
            
            // Cria um novo quiz para este jogador
            Quiz quiz = new Quiz(jogador);
            
            // Carrega as perguntas no quiz
            carregarPerguntas(quiz);
            
            // Inicia o quiz
            quiz.iniciar();
            
            // Pergunta se deseja jogar novamente
            perguntarJogarNovamente();
            
            // Fecha o quiz
            quiz.fechar();
            
        } catch (Exception e) {
            System.out.println("Erro: " + e.getMessage());
            e.printStackTrace();
        } finally {
            scanner.close();
        }
    }
    
    /**
     * Carrega as perguntas no quiz.
     * 
     * POLIMORFISMO: Adiciona diferentes tipos de perguntas
     * (PerguntaMultiplaEscolha e PerguntaVerdadeiroFalso)
     * como se fossem Pergunta (superclasse).
     * 
     * @param quiz o quiz onde adicionar as perguntas
     */
    private static void carregarPerguntas(Quiz quiz) {
        // Pergunta 1: Múltipla Escolha
        PerguntaMultiplaEscolha pergunta1 = new PerguntaMultiplaEscolha(
            "Qual é o principal objetivo da Orientação a Objetos?",
            10,
            new String[]{
                "Organizar o código em estruturas lógicas e reutilizáveis",
                "Aumentar a velocidade de execução do programa",
                "Reduzir o tamanho do arquivo executável",
                "Facilitar a compilação do código"
            },
            'A'
        );
        quiz.adicionarPergunta(pergunta1);
        
        // Pergunta 2: Verdadeiro ou Falso
        PerguntaVerdadeiroFalso pergunta2 = new PerguntaVerdadeiroFalso(
            "Encapsulamento é a prática de esconder os detalhes internos de uma classe e " +
            "expor apenas o necessário através de uma interface pública.",
            10,
            true
        );
        quiz.adicionarPergunta(pergunta2);
        
        // Pergunta 3: Múltipla Escolha
        PerguntaMultiplaEscolha pergunta3 = new PerguntaMultiplaEscolha(
            "Qual é a diferença entre herança e composição?",
            10,
            new String[]{
                "Herança é um relacionamento 'é um', composição é um relacionamento 'tem um'",
                "São exatamente a mesma coisa com nomes diferentes",
                "Herança é usada apenas em classes abstratas",
                "Composição não permite reutilização de código"
            },
            'A'
        );
        quiz.adicionarPergunta(pergunta3);
        
        // Pergunta 4: Verdadeiro ou Falso
        PerguntaVerdadeiroFalso pergunta4 = new PerguntaVerdadeiroFalso(
            "Polimorfismo permite que objetos de diferentes classes sejam usados " +
            "de forma intercambiável através de uma referência da superclasse.",
            10,
            true
        );
        quiz.adicionarPergunta(pergunta4);
        
        // Pergunta 5: Múltipla Escolha (Adicional)
        PerguntaMultiplaEscolha pergunta5 = new PerguntaMultiplaEscolha(
            "O que é uma classe abstrata?",
            10,
            new String[]{
                "Uma classe que não pode ser instanciada e define um contrato para subclasses",
                "Uma classe que herda de multiple classes",
                "Uma classe que implementa todas as interfaces",
                "Uma classe que não tem nenhum método"
            },
            'A'
        );
        quiz.adicionarPergunta(pergunta5);
    }
    
    /**
     * Pergunta ao jogador se deseja jogar novamente.
     */
    private static void perguntarJogarNovamente() {
        System.out.print("\nDeseja jogar novamente? (S/N): ");
        String resposta = scanner.nextLine().trim().toUpperCase();
        
        if (resposta.equals("S")) {
            // Recursivamente chama main novamente
            // Em uma aplicação real, seria melhor usar um loop
            main(new String[]{});
        } else {
            System.out.println("\nObrigado por jogar! Até logo!");
            System.out.println("Total de quizzes jogados: " + Jogador.getTotalQuizzesJogados());
        }
    }
}
