import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 * Classe que controla o fluxo do quiz.
 * 
 * CONCEITOS POO APLICADOS:
 * - COMPOSIÇÃO: Contém uma lista de Pergunta e um Jogador
 * - POLIMORFISMO: Lista de tipo Pergunta armazena diferentes subclasses
 *   (PerguntaMultiplaEscolha e PerguntaVerdadeiroFalso)
 * - ENCAPSULAMENTO: Atributos privados com acesso controlado
 * - VISIBILIDADE: Métodos privados e públicos bem definidos
 * 
 * Esta classe orquestra todo o jogo: carrega perguntas, controla
 * a interação com o jogador, calcula pontuação e usa o sistema de logs.
 */
public class Quiz {
    
    // COMPOSIÇÃO: Contém uma lista de Pergunta (polimorfismo)
    // Isso permite armazenar diferentes tipos de perguntas na mesma lista
    private List<Pergunta> perguntas;
    
    // COMPOSIÇÃO: Contém um Jogador
    private Jogador jogador;
    
    // ENCAPSULAMENTO: Atributo privado para o sistema de logs
    private SistemaLogs logs;
    
    // ENCAPSULAMENTO: Scanner privado para entrada de dados
    private Scanner scanner;
    
    /**
     * Construtor do Quiz que inicializa os componentes.
     * 
     * @param jogador o jogador que vai participar do quiz
     */
    public Quiz(Jogador jogador) {
        this.jogador = jogador;
        this.perguntas = new ArrayList<>(); // Lista de Pergunta (polimorfismo)
        this.logs = new SistemaLogs();
        this.scanner = new Scanner(System.in);
    }
    
    // GETTERS (ENCAPSULAMENTO)
    
    public Jogador getJogador() {
        return jogador;
    }
    
    public List<Pergunta> getPerguntas() {
        return perguntas;
    }
    
    public int getTotalPerguntas() {
        return perguntas.size();
    }
    
    /**
     * Adiciona uma pergunta ao quiz.
     * 
     * POLIMORFISMO: Aceita qualquer tipo de Pergunta (superclasse).
     * Pode ser PerguntaMultiplaEscolha, PerguntaVerdadeiroFalso, etc.
     * 
     * @param pergunta a pergunta a adicionar
     */
    public void adicionarPergunta(Pergunta pergunta) {
        if (pergunta != null) {
            this.perguntas.add(pergunta);
        }
    }
    
    /**
     * Inicia o quiz e controla todo o fluxo do jogo.
     * 
     * COMPOSIÇÃO: Utiliza os componentes (Jogador, Perguntas, SistemaLogs)
     * para executar o quiz.
     */
    public void iniciar() {
        // Registra o início do quiz
        logs.registrarEvento("Quiz iniciado", 1);
        logs.registrarEvento("Jogador " + jogador.getNome() + " começou a jogar", 1);
        
        System.out.println("\n========================================");
        System.out.println("Bem-vindo ao Quiz de POO!");
        System.out.println("========================================");
        System.out.println("Jogador: " + jogador.getNome());
        System.out.println("Total de perguntas: " + perguntas.size());
        System.out.println("========================================\n");
        
        int numeroPerguita = 1;
        
        // Itera sobre cada pergunta (POLIMORFISMO em ação)
        for (Pergunta pergunta : perguntas) {
            System.out.println("\n--- Pergunta " + numeroPerguita + " de " + perguntas.size() + " ---");
            pergunta.exibir();
            
            // Lê a resposta do jogador
            String resposta = scanner.nextLine().trim();
            
            // Verifica se a resposta está correta (POLIMORFISMO)
            // Cada tipo de pergunta tem sua própria implementação de verificarResposta
            boolean acertou = pergunta.verificarResposta(resposta);
            
            // Calcula a pontuação (POLIMORFISMO)
            // Cada tipo de pergunta tem sua própria implementação de calcularPontuacao
            int pontuacao = pergunta.calcularPontuacao();
            
            // Adiciona pontos ao jogador
            jogador.adicionarPontos(pontuacao);
            
            // Registra o evento com sobrecarga do SistemaLogs
            if (acertou) {
                logs.registrarEvento("Resposta CORRETA!", jogador.getNome(), resposta, pontuacao);
                System.out.println("✓ Correto! Você ganhou " + pontuacao + " pontos!");
            } else {
                logs.registrarEvento("Resposta INCORRETA!", jogador.getNome(), resposta, pontuacao);
                System.out.println("✗ Incorreto! Você " + (pontuacao < 0 ? "perdeu " + Math.abs(pontuacao) : "não ganhou pontos") + ".");
            }
            
            numeroPerguita++;
        }
        
        // Finaliza o quiz
        finalizarQuiz();
    }
    
    /**
     * Finaliza o quiz e exibe os resultados.
     * 
     * Registra evento de finalização e incrementa o contador
     * estático de quizzes jogados.
     */
    private void finalizarQuiz() {
        System.out.println("\n========================================");
        System.out.println("Quiz Finalizado!");
        System.out.println("========================================");
        System.out.println(jogador.toString());
        System.out.println("Total de quizzes jogados: " + Jogador.getTotalQuizzesJogados());
        System.out.println("========================================\n");
        
        // Registra a finalização do quiz
        logs.registrarEvento("Quiz finalizado", 1);
        logs.registrarEvento("Pontuação final de " + jogador.getNome() + ": " + jogador.getPontuacao(), 1);
        
        // Incrementa o contador estático de quizzes (MÉTODO ESTÁTICO)
        Jogador.incrementarQuizzesJogados();
    }
    
    /**
     * Fecha o scanner para liberar recursos.
     */
    public void fechar() {
        scanner.close();
    }
}
