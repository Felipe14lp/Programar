#!/bin/bash
# Script para compilar e executar o Quiz de POO

echo "========================================"
echo "Compilando arquivos Java..."
echo "========================================"

javac Pontuavel.java
javac Pergunta.java
javac PerguntaMultiplaEscolha.java
javac PerguntaVerdadeiroFalso.java
javac Jogador.java
javac SistemaLogs.java
javac Quiz.java
javac App.java

if [ $? -ne 0 ]; then
    echo "Erro na compilacao!"
    exit 1
fi

echo "========================================"
echo "Compilacao concluida com sucesso!"
echo "========================================"
echo ""

echo "Executando o programa..."
echo "========================================"
java App
