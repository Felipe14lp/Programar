/**
 * Interface que define o contrato para classes que possuem pontuação.
 * Demonstra abstração através da interface, permitindo polimorfismo.
 * 
 * CONCEITO POO: ABSTRAÇÃO E INTERFACES
 * Define um contrato que deve ser implementado por classes que calculam pontuação.
 * Isso permite diferentes formas de cálculo de pontos em diferentes tipos de perguntas.
 */
public interface Pontuavel {
    /**
     * Calcula a pontuação para uma pergunta respondida.
     * 
     * @return a pontuação em pontos
     */
    int calcularPontuacao();
}
