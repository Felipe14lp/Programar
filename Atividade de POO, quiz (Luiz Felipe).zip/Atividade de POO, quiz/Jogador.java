/**
 * Classe que representa um jogador do quiz.
 * 
 * CONCEITOS POO APLICADOS:
 * - ENCAPSULAMENTO: Atributos privados com validação via getters e setters
 * - ATRIBUTOS ESTÁTICOS: Contador de total de quizzes jogados
 * - MÉTODOS ESTÁTICOS: getTotalQuizzesJogados()
 * - VISIBILIDADE: Uso apropriado de private, public e static
 * 
 * Esta classe armazena as informações do jogador e mantém a contagem
 * global de quantos quizzes foram jogados por todos os jogadores.
 */
public class Jogador {
    
    // ENCAPSULAMENTO: Atributos privados
    private String nome;
    private int pontuacao;
    
    // ATRIBUTOS ESTÁTICOS: Compartilhado entre todas as instâncias
    // Conta quantos quizzes foram jogados no total
    private static int totalQuizzesJogados = 0;
    
    /**
     * Construtor que inicializa um jogador com seu nome.
     * 
     * @param nome o nome do jogador
     */
    public Jogador(String nome) {
        this.setNome(nome);
        this.pontuacao = 0;
    }
    
    // GETTERS E SETTERS COM VALIDAÇÃO (ENCAPSULAMENTO)
    
    public String getNome() {
        return nome;
    }
    
    public void setNome(String nome) {
        if (nome == null || nome.trim().isEmpty()) {
            throw new IllegalArgumentException("Nome não pode ser vazio!");
        }
        this.nome = nome.trim();
    }
    
    public int getPontuacao() {
        return pontuacao;
    }
    
    public void setPontuacao(int pontuacao) {
        if (pontuacao < 0) {
            throw new IllegalArgumentException("Pontuação não pode ser negativa!");
        }
        this.pontuacao = pontuacao;
    }
    
    /**
     * Adiciona pontos à pontuação do jogador.
     * 
     * @param pontos os pontos a adicionar
     */
    public void adicionarPontos(int pontos) {
        this.pontuacao += pontos;
        if (this.pontuacao < 0) {
            this.pontuacao = 0; // Garante que não fica negativo
        }
    }
    
    /**
     * MÉTODO ESTÁTICO: Incrementa o contador de quizzes jogados.
     * Deve ser chamado quando um quiz é finalizado.
     */
    public static void incrementarQuizzesJogados() {
        Jogador.totalQuizzesJogados++;
    }
    
    /**
     * MÉTODO ESTÁTICO: Retorna o total de quizzes jogados.
     * 
     * @return o total de quizzes jogados por todos os jogadores
     */
    public static int getTotalQuizzesJogados() {
        return Jogador.totalQuizzesJogados;
    }
    
    /**
     * MÉTODO ESTÁTICO: Reseta o contador de quizzes jogados.
     * Útil para testes ou reinicializar o programa.
     */
    public static void resetarQuizzesJogados() {
        Jogador.totalQuizzesJogados = 0;
    }
    
    @Override
    public String toString() {
        return "Jogador: " + nome + " | Pontuação: " + pontuacao;
    }
}
