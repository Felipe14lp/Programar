# Quiz Interativo de Programação Orientada a Objetos

Um projeto educacional em Java que implementa um quiz interativo no console, demonstrando os principais conceitos de Programação Orientada a Objetos (POO).

## 📋 Conteúdo do Projeto

O projeto contém os seguintes arquivos:

1. **Pontuavel.java** - Interface
2. **Pergunta.java** - Classe abstrata
3. **PerguntaMultiplaEscolha.java** - Implementação de pergunta
4. **PerguntaVerdadeiroFalso.java** - Implementação de pergunta
5. **Jogador.java** - Classe de modelo
6. **SistemaLogs.java** - Classe utilitária
7. **Quiz.java** - Classe de controlador
8. **App.java** - Classe principal
9. **README.md** - Este arquivo

## 🚀 Como Executar

### Pré-requisitos
- Java Development Kit (JDK) 8 ou superior
- Um compilador Java (javac)

### Passos para Compilar

1. Navegue até a pasta do projeto:
```bash
cd "Atividade de POO, quiz"
```

2. Compile todos os arquivos Java:
```bash
javac *.java
```

3. Execute o programa:
```bash
java App
```

### Interação com o Programa

1. Digite seu nome quando solicitado
2. Responda às perguntas do quiz
3. Para perguntas de múltipla escolha, digite: A, B, C ou D
4. Para perguntas verdadeiro/falso, digite: V ou F
5. Ao final, você verá sua pontuação e o total de quizzes jogados
6. Será perguntado se deseja jogar novamente

## 📚 Conceitos de POO Aplicados

### 1. **ABSTRAÇÃO**
- **Arquivo:** `Pergunta.java`
- **Descrição:** A classe `Pergunta` é abstrata com método abstrato `verificarResposta()`. Define um contrato que todas as perguntas devem seguir sem especificar a implementação.
- **Benefício:** Permite trabalhar com diferentes tipos de perguntas uniformemente.

### 2. **ENCAPSULAMENTO**
- **Arquivos:** Todas as classes
- **Descrição:** Todos os atributos são `private` com acesso através de `getters` e `setters` públicos. Os setters incluem validação.
- **Exemplo em `Pergunta.java`:**
```java
private String enunciado;
private int pontosPorAcerto;

public void setEnunciado(String enunciado) {
    if (enunciado == null || enunciado.trim().isEmpty()) {
        throw new IllegalArgumentException("Enunciado não pode ser vazio!");
    }
    this.enunciado = enunciado;
}
```
- **Benefício:** Protege a integridade dos dados e permite validação centralizada.

### 3. **HERANÇA**
- **Arquivos:** `PerguntaMultiplaEscolha.java` e `PerguntaVerdadeiroFalso.java`
- **Descrição:** Ambas as classes herdam de `Pergunta`, reutilizando comportamentos comuns e adicionando comportamentos específicos.
- **Exemplo:**
```java
public class PerguntaMultiplaEscolha extends Pergunta {
    // Herda métodos e atributos de Pergunta
}
```
- **Benefício:** Reutilização de código e organização hierárquica.

### 4. **SUPER() - Construtor com Herança**
- **Arquivos:** `PerguntaMultiplaEscolha.java` e `PerguntaVerdadeiroFalso.java`
- **Descrição:** Chama o construtor da superclasse usando `super()` para inicializar atributos herdados.
- **Exemplo em `PerguntaMultiplaEscolha.java`:**
```java
public PerguntaMultiplaEscolha(String enunciado, int pontosPorAcerto, 
                               String[] opcoes, char respostaCorreta) {
    super(enunciado, pontosPorAcerto); // SUPER: Chamando construtor da superclasse
    // ... inicializa atributos específicos
}
```
- **Benefício:** Garante inicialização correta da superclasse.

### 5. **POLIMORFISMO**
- **Arquivos:** `Quiz.java` (lista de perguntas)
- **Descrição:** Uma lista de tipo `Pergunta` armazena objetos de diferentes subclasses (`PerguntaMultiplaEscolha` e `PerguntaVerdadeiroFalso`), cada um respondendo ao método `verificarResposta()` de forma diferente.
- **Exemplo em `Quiz.java`:**
```java
private List<Pergunta> perguntas; // Lista de superclasse

// Cada elemento pode ser PerguntaMultiplaEscolha ou PerguntaVerdadeiroFalso
for (Pergunta pergunta : perguntas) {
    boolean acertou = pergunta.verificarResposta(resposta); // Polimorfismo!
    int pontuacao = pergunta.calcularPontuacao(); // Cada uma tem sua implementação
}
```
- **Benefício:** Flexibilidade e extensibilidade do código.

### 6. **COMPOSIÇÃO**
- **Arquivo:** `Quiz.java`
- **Descrição:** `Quiz` possui uma lista de `Pergunta` e um `Jogador`. Não herda delas, mas as utiliza internamente.
- **Exemplo:**
```java
public class Quiz {
    private List<Pergunta> perguntas; // Composição
    private Jogador jogador;          // Composição
}
```
- **Benefício:** Relacionamento "tem um" permite maior flexibilidade que herança.

### 7. **INTERFACE - Pontuavel**
- **Arquivo:** `Pontuavel.java`
- **Descrição:** Interface que define o contrato `calcularPontuacao()`. Implementada por `Pergunta`.
- **Benefício:** Define um contrato claro para classes que calculam pontuação.

### 8. **SOBRESCRITA (Override)**
- **Arquivos:** `PerguntaMultiplaEscolha.java` e `PerguntaVerdadeiroFalso.java`
- **Descrição:** Sobrescrevem o método abstrato `verificarResposta()` e `calcularPontuacao()` com implementações específicas.
- **Exemplo em `PerguntaMultiplaEscolha.java`:**
```java
@Override
public boolean verificarResposta(String resposta) {
    // Implementação específica para múltipla escolha
}

@Override
public int calcularPontuacao() {
    // Múltipla escolha: acertou ganha, errou perde metade
    return this.isRespostaCorreta() ? this.getPontosPorAcerto() : -(this.getPontosPorAcerto() / 2);
}
```
- **Benefício:** Personalização de comportamentos em subclasses.

### 9. **SOBRECARGA (Overload)**
- **Arquivo:** `SistemaLogs.java`
- **Descrição:** Método `registrarEvento()` com diferentes assinaturas:
  - `registrarEvento(String mensagem)`
  - `registrarEvento(String mensagem, int nivel)`
  - `registrarEvento(String mensagem, String nomeJogador, String resposta)`
  - `registrarEvento(String mensagem, String nomeJogador, String resposta, int pontuacao)`
- **Exemplo:**
```java
public void registrarEvento(String mensagem) { ... }
public void registrarEvento(String mensagem, int nivel) { ... }
public void registrarEvento(String mensagem, String nomeJogador, String resposta) { ... }
```
- **Benefício:** Interface flexível com múltiplas formas de uso.

### 10. **ATRIBUTOS E MÉTODOS ESTÁTICOS**
- **Arquivo:** `Jogador.java`
- **Descrição:** Atributo estático `totalQuizzesJogados` compartilhado entre todas as instâncias, com método estático `getTotalQuizzesJogados()`.
- **Exemplo:**
```java
public class Jogador {
    private static int totalQuizzesJogados = 0;
    
    public static void incrementarQuizzesJogados() {
        Jogador.totalQuizzesJogados++;
    }
    
    public static int getTotalQuizzesJogados() {
        return Jogador.totalQuizzesJogados;
    }
}
```
- **Benefício:** Compartilhamento de dados e comportamentos entre instâncias.

### 11. **VISIBILIDADE (Access Modifiers)**
- **Aplicado em:** Todas as classes
- **Descrição:**
  - `private`: Atributos da classe, métodos auxiliares
  - `public`: Métodos de acesso controlado, classes principais
  - `protected`: Métodos acessíveis por subclasses em `Pergunta`
- **Exemplo:**
```java
private String enunciado;        // Private: oculto
public String getEnunciado() {}  // Public: acesso controlado
protected Pergunta(...) {}       // Protected: acessível por subclasses
```
- **Benefício:** Controle fino sobre o que é exposto externamente.

### 12. **COESÃO E BAIXO ACOPLAMENTO**
- **Coesão Alta:**
  - Cada classe tem uma responsabilidade clara
  - `Pergunta`: Representa uma pergunta
  - `Jogador`: Representa um jogador
  - `Quiz`: Controla o fluxo do jogo
  - `SistemaLogs`: Registra eventos
  
- **Baixo Acoplamento:**
  - `Quiz` depende de `Pergunta` (abstração), não de implementações concretas
  - `App` cria instâncias, mas as classes são fracamente acopladas
  - Uso de interfaces (`Pontuavel`) reduz dependências

## 🎮 Fluxo da Aplicação

1. **App.java** (main)
   - Solicita nome do jogador
   - Cria instância de `Jogador`
   - Cria instância de `Quiz`
   - Carrega perguntas (composição)

2. **Quiz.java**
   - Itera sobre a lista polimórfica de `Pergunta`
   - Para cada pergunta:
     - Exibe a pergunta (sobrescrita)
     - Verifica resposta (polimorfismo)
     - Calcula pontuação (interface Pontuavel)
     - Registra evento (sobrecarga de SistemaLogs)

3. **SistemaLogs.java**
   - Registra eventos com diferentes parâmetros (sobrecarga)

4. **Jogador.java**
   - Acumula pontuação
   - Incrementa contador estático de quizzes

## 📊 Sistema de Pontuação

- **Pergunta Múltipla Escolha:**
  - Acerto: +10 pontos
  - Erro: -5 pontos (metade da pontuação)

- **Pergunta Verdadeiro/Falso:**
  - Acerto: +10 pontos
  - Erro: 0 pontos (sem penalidade)

## 📝 Exemplos de Entrada

### Pergunta 1 - Múltipla Escolha
```
Digite seu nome: João Silva
--- Pergunta 1 de 4 ---

Qual é o principal objetivo da Orientação a Objetos?
Opções:
  A) Organizar o código em estruturas lógicas e reutilizáveis
  B) Aumentar a velocidade de execução do programa
  C) Reduzir o tamanho do arquivo executável
  D) Facilitar a compilação do código
Sua resposta (A/B/C/D): A
✓ Correto! Você ganhou 10 pontos!
```

### Pergunta 2 - Verdadeiro/Falso
```
--- Pergunta 2 de 4 ---

Encapsulamento é a prática de esconder os detalhes internos...
Opções:
  V) Verdadeiro
  F) Falso
Sua resposta (V/F): V
✓ Correto! Você ganhou 10 pontos!
```

## 🏆 Resultado Final

```
========================================
Quiz Finalizado!
========================================
Jogador: João Silva | Pontuação: 40
Total de quizzes jogados: 1
========================================
```

## 📚 Estrutura de Dados

```
App
├── Jogador (composição)
│   └── nome (String)
│   └── pontuacao (int)
│   └── totalQuizzesJogados (static int)
│
├── Quiz (composição)
│   ├── perguntas (List<Pergunta>) - POLIMORFISMO
│   │   ├── PerguntaMultiplaEscolha
│   │   │   ├── enunciado
│   │   │   ├── pontosPorAcerto
│   │   │   ├── opcoes[]
│   │   │   └── respostaCorretaLetra
│   │   │
│   │   └── PerguntaVerdadeiroFalso
│   │       ├── enunciado
│   │       ├── pontosPorAcerto
│   │       └── respostaVerdadeira
│   │
│   ├── jogador (Jogador)
│   └── logs (SistemaLogs)
│
└── SistemaLogs
    └── registrarEvento() - SOBRECARGA
```

## 💡 Lições de POO Demonstradas

1. **Abstração**: Use classes abstratas para definir comportamentos comum
2. **Encapsulamento**: Proteja dados com validação em setters
3. **Herança**: Reutilize código através de hierarquias
4. **Polimorfismo**: Trate objetos diferentes uniformemente
5. **Interfaces**: Defina contratos independentes de implementação
6. **Composição**: Prefira "tem um" sobre "é um"
7. **Sobrecarga**: Forneça múltiplas formas de chamada
8. **Estáticos**: Compartilhe dados entre instâncias
9. **Visibilidade**: Controle acesso aos membros da classe
10. **Coesão**: Cada classe tem uma responsabilidade clara

## 🔧 Melhorias Futuras

- Adicionar persistência em banco de dados
- Implementar diferentes dificuldades
- Adicionar sistema de ranking
- Criar interface gráfica
- Adicionar mais tipos de perguntas
- Implementar sistema de categorias

## 📄 Licença

Este projeto é fornecido como material educacional.

## 👨‍💻 Autor

Projeto de Programação Orientada a Objetos - Atividade de Quiz

---

**Versão:** 1.0  
**Data:** Dezembro 2025  
**Linguagem:** Java
